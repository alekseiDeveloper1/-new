<?php
	
class MathTest extends Test
{
	function test_core(){
	//	$this->assertCoverage('cms/cms.php');
	}

}
 
?>