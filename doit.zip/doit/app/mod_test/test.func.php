<?php

function test_run_test()
{





	d()->Test->runAll();

	//d()->HelpersTest->run();


}

?>